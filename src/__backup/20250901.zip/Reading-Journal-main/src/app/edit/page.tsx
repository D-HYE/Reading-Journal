'use client'; 

import { createClient } from '@/utils/supabase/client';

import React, { useEffect, useState }  from 'react'
import { useSearchParams, useRouter } from 'next/navigation';


import Layout from '@/components/JournalLayout';
import { BackspaceBtn, SqureBtn, Loading } from '@/ui/ui'


export default function Page() {
    const journalParams = useSearchParams();
    const id = journalParams.get('id');
    const router = useRouter();

    const [journal, setJournal] = useState<Journal | null>(null);

    useEffect(() => {
        if (!id) return;

        const fetchData = async () => {
            const supabase = await createClient();
            const { data, error } = await supabase
                .from('reading_journal')
                .select('*')
                .eq('journal_id', id)
                .single();

            if (!error && data) setJournal(data as Journal);
        };

        fetchData();
    }, [id]);

    if (!journal) return <Loading>독서노트 불러오는 중...</Loading>;

    const handleChange = (field: keyof Journal, value: any) => {
        setJournal((prev) => ({ ...prev, [field]: value }));
    };
    
    const saveJournal = async () =>{
        if (!journal) return;
        const supabase = await createClient();
        const { error } = await supabase
            .from('reading_journal')
            .update({
                book_title: journal.book_title,
                book_cover: journal.book_cover,
                book_author: journal.book_author,
                start_date: journal.start_date,
                end_date: journal.end_date,
                rating: journal.rating,
                content: journal.content,
                password: journal.password,
                secret: journal.secret
            })
            .eq('journal_id', id)
            .single();

        if (error) {
            console.error('업데이트 실패', error);
            alert('노트 수정 실패하였습니다.');
            return;
        }
        alert('노트 수정을 완료하였습니다.');
        router.push(`/list/detail?id=${id}&from=edited`);
    }

    return (
      <div>
          <BackspaceBtn/>
          <Layout mode='edit' journal={journal} onChange={handleChange} />
          <div className="flex justify-center py-8">
            <SqureBtn className='text-[var(--c-border)]' onClick={saveJournal}>저장</SqureBtn>
          </div>
      </div>
    )
}
