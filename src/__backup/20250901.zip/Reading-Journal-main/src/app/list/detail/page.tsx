'use client'; 

import { createClient } from '@/utils/supabase/client';

import React, { useEffect, useState }  from 'react'
import Link from 'next/link';
import { useSearchParams, useRouter } from 'next/navigation';

import Layout from '@/components/JournalLayout';

import { BackspaceBtn, SqureBtn, Popup, Loading } from '@/ui/ui'
import style from '@/ui/input.module.scss'



export default function Page() {
    const journalParams = useSearchParams();
    const id = journalParams.get('id');
    const router = useRouter();

    const [journal, setJournal] = useState<Journal | null>(null);
    const [editOpen, setEditOpen] = useState(false);
    const [deleteOpen, setDeleteOpen] = useState(false);
    const [password, setPassword] = useState('');

    useEffect(() => {
        if (!id) return;

        const fetchData = async () => {
            const supabase = await createClient();
            const { data, error } = await supabase
                .from('reading_journal')
                .select('*')
                .eq('journal_id', id)
                .single();

            if (!error && data) setJournal(data as Journal);
        };

        fetchData();
    }, [id]);

    if (!journal) return <Loading>독서노트 불러오는 중...</Loading>;

    const handleChange = (field: keyof Journal, value: any) => {
        setJournal((prev) => ({ ...prev, [field]: value }));
    };

    const editPwConfirm = () => {
        if (password === journal?.password) {
            router.push(`/edit?id=${journal.journal_id}`);
        } else {
            alert('비밀번호가 일치하지 않습니다!');
        }   
    }

    const deletePwConfirm = async () =>{
        const supabase = await createClient();
        
        if (password === journal?.password) {

            const { error } = await supabase
                .from('reading_journal')
                .delete()
                .eq('journal_id', id)
    
            if(error){
                alert('독서노트 삭제에 실패했습니다.');
                return;
            }

            alert('독서노트를 삭제하였습니다.');
            router.push('/');
            return;
            
        } else {
            alert('비밀번호가 일치하지 않습니다!');
        }   
    }

    return (
        <div >
            <BackspaceBtn/>
            <Layout journal={journal}
                mode='detail'
                onChange={handleChange}
                onDeleteClick={() => setDeleteOpen(true)}
            />
            <div className="flex justify-center gap-2 py-8">
                <Link href="/"><SqureBtn className='bg-[var(--d-gr2)] text-[var(--d-gr1)]'>목록</SqureBtn></Link>
                <SqureBtn className='text-[var(--c-border)]' onClick={()=>setEditOpen(true)}>수정</SqureBtn>
            </div>
            {editOpen && (
                <Popup onClose={()=>setEditOpen(false)}>
                    <p className='mb-2'>비밀번호를 입력하세요.</p>
                    <input
                        type="password"
                        className={`${style.default}`}
                        onChange={(e) => setPassword(e.target.value)}
                        onKeyDown={(e)=>{
                            if (e.key === 'Enter'){editPwConfirm();}
                        }}
                    />
                    <SqureBtn className='mt-4 bg-[var(--c-border)] text-[var(--c-content)]' onClick={editPwConfirm}>확인</SqureBtn>
                </Popup>
            )}
            {deleteOpen && (
                <Popup onClose={()=>setDeleteOpen(false)}>
                    <p className='mb-2'>비밀번호를 입력하세요.</p>
                    <input
                        type="password"
                        className={`${style.default}`}
                        onChange={(e) => setPassword(e.target.value)}
                        onKeyDown={(e)=>{
                            if (e.key === 'Enter'){deletePwConfirm();}
                        }}
                    />
                    <SqureBtn className='mt-4 bg-[var(--c-border)] text-[var(--c-content)]' onClick={deletePwConfirm}>확인</SqureBtn>
                </Popup>
            )}

        </div>
    )
}
